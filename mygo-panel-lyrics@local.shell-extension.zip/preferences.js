import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk?version=4.0';

export function buildPreferences(window, settings) {
    const page = new Adw.PreferencesPage({title: '顶栏歌词', icon_name: 'audio-x-generic-symbolic'});
    window.add(page);
    const group = (title, description = '') => {
        const widget = new Adw.PreferencesGroup({title, description});
        page.add(widget);
        return widget;
    };
    const choice = (parent, key, title, values, labels, subtitle = '') => {
        const row = new Adw.ComboRow({title, subtitle, model: Gtk.StringList.new(labels)});
        row.selected = Math.max(0, values.indexOf(settings.get_string(key)));
        row.connect('notify::selected', () => settings.set_string(key, values[row.selected]));
        parent.add(row);
        return row;
    };
    const number = (parent, key, title, min, max, step, subtitle = '') => {
        const row = new Adw.SpinRow({title, subtitle, adjustment: new Gtk.Adjustment({
            lower: min, upper: max, step_increment: step, page_increment: step * 5})});
        settings.bind(key, row, 'value', Gio.SettingsBindFlags.DEFAULT);
        parent.add(row);
        return row;
    };
    const toggle = (parent, key, title, subtitle = '') => {
        const row = new Adw.SwitchRow({title, subtitle});
        settings.bind(key, row, 'active', Gio.SettingsBindFlags.DEFAULT);
        parent.add(row);
    };

    const location = group('显示位置', 'Ubuntu GNOME 顶栏，修改后立即生效。区域内序号从 0 开始。');
    choice(location, 'position', '顶栏区域', ['left', 'center', 'right'], ['左侧', '中间', '右侧']);
    number(location, 'panel-index', '区域内序号', 0, 20, 1, '调整与时钟、系统图标的相对次序');
    choice(location, 'alignment', '文字对齐', ['left', 'center', 'right'], ['左对齐', '居中', '右对齐']);

    const length = group('显示长度', '字符按可见字形计算，保留完整的 Emoji 和组合字符。');
    number(length, 'max-chars', '最大字符数', 4, 120, 1);
    number(length, 'max-width', '显示宽度（逻辑像素）', 80, 1200, 10, '实际宽度同时限制在主屏幕宽度的 40% 以内');
    number(length, 'font-size', '字号', 9, 24, 1);
    choice(length, 'overflow', '超长歌词', ['ellipsis', 'scroll'], ['省略号截断', '横向滚动']);
    number(length, 'scroll-ms', '滚动间隔（毫秒 / 字符）', 80, 2000, 10, '每句先停留 1 秒；暂停时停止滚动');

    const effect = group('歌词交替样式', '切换效果跟随每句歌词；系统关闭动画时使用直接切换。');
    choice(effect, 'transition', '切换效果', ['none', 'fade', 'slide'], ['直接切换', '淡入淡出', '上下滑动']);
    number(effect, 'transition-ms', '动画总时长（毫秒）', 0, 1000, 10);
    number(effect, 'offset-ms', '同步微调（毫秒）', -10000, 10000, 50, '正数让歌词提前，负数让歌词延后');
    toggle(effect, 'hide-paused', '暂停时隐藏歌词');
    toggle(effect, 'show-track', '无歌词或间奏时显示歌名');

    const source = group('歌词来源', '默认复用网易云音乐源已返回的原始歌词，不再查询其他歌词服务。');
    choice(source, 'lyric-source', '读取方式', ['plugin', 'fallback'], ['网易云原始歌词', '独立匹配（本地 / 在线）'],
        '原始歌词需要安装网易云转发补丁，并在 MyGo 允许插件启动 gjs');
    toggle(source, 'show-translation', '同时显示来源翻译', '仅用于原始歌词；翻译和原文在同一行显示');
    toggle(source, 'online-enabled', '独立匹配时允许在线查询', '仅在选择独立匹配后生效；向 lrclib.net 发送歌曲元数据');
    const directory = new Adw.EntryRow({title: '本地 LRC 目录（可用 ~/）', show_apply_button: true});
    directory.text = settings.get_string('local-directory');
    directory.connect('apply', () => settings.set_string('local-directory', directory.text.trim()));
    source.add(directory);
    const folder = new Adw.ActionRow({title: '选择歌词文件夹',
        subtitle: '文件名：歌手 - 歌名.lrc 或 歌名.lrc；UTF-8 编码'});
    const button = new Gtk.Button({label: '选择…', valign: Gtk.Align.CENTER});
    button.connect('clicked', () => {
        const chooser = new Gtk.FileDialog({title: '选择 LRC 歌词文件夹'});
        chooser.select_folder(window, null, (dialog, result) => {
            try {
                const path = dialog.select_folder_finish(result).get_path();
                if (path) {
                    settings.set_string('local-directory', path);
                    directory.text = path;
                }
            } catch (_) { /* User cancelled the chooser. */ }
        });
    });
    folder.add_suffix(button);
    folder.activatable_widget = button;
    source.add(folder);

    const about = group('使用说明');
    about.add(new Adw.ActionRow({title: '跟随 MyGo Music 的播放、暂停、跳转和切歌',
        subtitle: '通过 MPRIS 只读获取播放进度；不控制播放器、不读取账号和音频。'}));
    about.add(new Adw.ActionRow({title: '点击顶栏歌词可查看来源、重新读取及打开设置',
        subtitle: '原始模式需重新播放歌曲以触发来源返回歌词。退出 MyGo 后自动隐藏。'}));
}
