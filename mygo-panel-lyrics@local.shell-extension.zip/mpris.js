import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import {cleanText, positionAt} from './core.js';

const PATH = '/org/mpris/MediaPlayer2';
const PLAYER = 'org.mpris.MediaPlayer2.Player';
const PREFIX = 'org.mpris.MediaPlayer2.MyGo_Music';
const now = () => GLib.get_monotonic_time() / 1000;
const unpack = value => value instanceof GLib.Variant ? unpack(value.deepUnpack()) :
    Array.isArray(value) ? value.map(unpack) : value && typeof value === 'object' ?
        Object.fromEntries(Object.entries(value).map(([key, item]) => [key, unpack(item)])) : value;

export class MprisWatcher {
    constructor(onChange) {
        this._onChange = onChange;
        this._cancel = new Gio.Cancellable();
        this._entries = new Map();
        this._subscriptions = [];
        this._alive = true;
    }

    async start() {
        try {
            this._bus = await new Promise((resolve, reject) => Gio.bus_get(Gio.BusType.SESSION,
                this._cancel, (_source, result) => {
                    try { resolve(Gio.bus_get_finish(result)); } catch (error) { reject(error); }
                }));
            if (!this._alive)
                return;
            this._subscriptions.push(this._bus.signal_subscribe('org.freedesktop.DBus',
                'org.freedesktop.DBus', 'NameOwnerChanged', '/org/freedesktop/DBus', null,
                Gio.DBusSignalFlags.NONE, (_c, _s, _p, _i, _m, args) => {
                    const [name, , owner] = args.deepUnpack();
                    if (!this._matches(name))
                        return;
                    this._entries.delete(name);
                    if (owner)
                        this._add(name);
                    this._emit();
                }));
            this._subscriptions.push(this._bus.signal_subscribe(null,
                'org.freedesktop.DBus.Properties', 'PropertiesChanged', PATH, PLAYER,
                Gio.DBusSignalFlags.NONE, (_c, sender) => this._signal(sender)));
            this._subscriptions.push(this._bus.signal_subscribe(null, PLAYER, 'Seeked', PATH,
                null, Gio.DBusSignalFlags.NONE, (_c, sender, _p, _i, _m, args) => {
                    for (const entry of this._entries.values()) {
                        if (entry.owner === sender && entry.state) {
                            entry.revision++;
                            entry.state.position = Number(args.deepUnpack()[0]) / 1000;
                            entry.state.observedAt = now();
                            this._emit();
                        }
                    }
                }));
            const reply = await this._call('org.freedesktop.DBus', '/org/freedesktop/DBus',
                'org.freedesktop.DBus', 'ListNames', null);
            for (const name of reply.deepUnpack()[0]) {
                if (this._matches(name) && !this._entries.has(name))
                    this._add(name);
            }
            this._timer = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 2000, () => {
                for (const entry of this._entries.values())
                    this._refresh(entry);
                return GLib.SOURCE_CONTINUE;
            });
        } catch (error) {
            if (!this._cancel.is_cancelled())
                console.error('MyGo 顶栏歌词：媒体总线不可用');
        }
    }

    _matches(name) { return name === PREFIX || name.startsWith(`${PREFIX}.`); }

    _call(name, path, iface, method, args) {
        return new Promise((resolve, reject) => this._bus.call(name, path, iface, method, args,
            null, Gio.DBusCallFlags.NONE, 3000, this._cancel, (bus, result) => {
                try { resolve(bus.call_finish(result)); } catch (error) { reject(error); }
            }));
    }

    async _add(name) {
        const entry = {name, revision: 0, busy: false};
        this._entries.set(name, entry);
        try {
            const owner = await this._call('org.freedesktop.DBus', '/org/freedesktop/DBus',
                'org.freedesktop.DBus', 'GetNameOwner', new GLib.Variant('(s)', [name]));
            if (!this._alive || this._entries.get(name) !== entry)
                return;
            entry.owner = owner.deepUnpack()[0];
            this._refresh(entry);
        } catch (_) { /* A player may exit between discovery and GetNameOwner. */ }
    }

    _signal(sender) {
        for (const entry of this._entries.values()) {
            if (entry.owner === sender) {
                entry.revision++;
                // Ignore any older pending reply and immediately fetch the new state.
                entry.again = true;
                this._refresh(entry);
            }
        }
    }

    async _refresh(entry) {
        if (!this._alive || entry.busy)
            return;
        entry.busy = true;
        entry.again = false;
        const revision = entry.revision;
        try {
            const reply = await this._call(entry.name, PATH, 'org.freedesktop.DBus.Properties',
                'GetAll', new GLib.Variant('(s)', [PLAYER]));
            if (!this._alive || this._entries.get(entry.name) !== entry || revision !== entry.revision)
                return;
            const props = unpack(reply)[0];
            const meta = props.Metadata ?? {};
            entry.state = {
                name: entry.name,
                id: String(meta['mpris:trackid'] ?? ''),
                title: cleanText(meta['xesam:title']),
                artist: cleanText((meta['xesam:artist'] ?? []).join(', ')),
                album: cleanText(meta['xesam:album']),
                duration: Math.max(0, Number(meta['mpris:length'] ?? 0) / 1000),
                position: Math.max(0, Number(props.Position ?? 0) / 1000),
                rate: Math.max(0, Number(props.Rate ?? 1)),
                playback: String(props.PlaybackStatus ?? 'Stopped'),
                observedAt: now(),
            };
            this._emit();
        } catch (_) {
            if (this._alive) {
                entry.state = null;
                this._emit();
            }
        } finally {
            entry.busy = false;
            if (entry.again && this._alive && this._entries.get(entry.name) === entry)
                this._refresh(entry);
        }
    }

    _emit() {
        if (!this._alive)
            return;
        const candidates = [...this._entries.values()].map(entry => entry.state)
            .filter(state => state?.title && state.playback !== 'Stopped');
        candidates.sort((a, b) => Number(b.playback === 'Playing') - Number(a.playback === 'Playing') ||
            a.name.localeCompare(b.name));
        this.state = candidates[0] ?? null;
        this._onChange(this.state);
    }

    position() { return this.state ? positionAt(this.state, now()) : 0; }

    destroy() {
        this._alive = false;
        this._cancel.cancel();
        if (this._timer)
            GLib.Source.remove(this._timer);
        for (const id of this._subscriptions)
            this._bus.signal_unsubscribe(id);
        this._entries.clear();
        this.state = null;
        this._onChange = null;
    }
}
