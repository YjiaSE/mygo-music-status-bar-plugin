import Gio from 'gi://Gio';
import {BUS_NAME, BUS_PATH, BUS_XML, MAX_PACKET, validatePacket, matchesPlayer} from './forward-contract.js';

export class ForwardReceiver {
    constructor(onUpdate) {
        this._onUpdate = onUpdate;
        this._cache = new Map();
        this._alive = true;
        this._owner = Gio.bus_own_name(Gio.BusType.SESSION, BUS_NAME, Gio.BusNameOwnerFlags.NONE,
            connection => {
                if (!this._alive)
                    return;
                this._object = Gio.DBusExportedObject.wrapJSObject(BUS_XML, {
                    Publish: serialized => this._publish(serialized),
                });
                this._object.export(connection, BUS_PATH);
            }, null, null);
    }

    _publish(serialized) {
        if (!this._alive || typeof serialized !== 'string' || serialized.length > MAX_PACKET)
            return false;
        let packet;
        try { packet = validatePacket(JSON.parse(serialized)); } catch (_) { return false; }
        if (!packet)
            return false;
        const key = `${packet.player}:${packet.playerTrackId}`;
        this._cache.delete(key);
        this._cache.set(key, {packet, receivedAt: Date.now()});
        if (this._cache.size > 16)
            this._cache.delete(this._cache.keys().next().value);
        this._onUpdate(packet);
        return true;
    }

    lookup(state) {
        if (!state)
            return null;
        const record = this._cache.get(`${state.name}:${state.id}`);
        return record && Date.now() - record.receivedAt < 30 * 60 * 1000 &&
            matchesPlayer(record.packet, state) ? record.packet.lyrics : null;
    }

    destroy() {
        this._alive = false;
        this._object?.unexport();
        this._object = null;
        if (this._owner)
            Gio.bus_unown_name(this._owner);
        this._owner = 0;
        this._cache.clear();
        this._onUpdate = null;
    }
}
