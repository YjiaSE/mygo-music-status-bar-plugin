// SPDX-License-Identifier: AGPL-3.0-only
// Shared local forwarding contract. No credentials, audio or remote API calls.
export const BUS_NAME = 'org.gnome.Shell.Extensions.MygoPanelLyrics';
export const BUS_PATH = '/org/gnome/Shell/Extensions/MygoPanelLyrics';
export const BUS_IFACE = BUS_NAME;
export const BUS_XML = `<node><interface name="${BUS_IFACE}">
  <method name="Publish"><arg type="s" direction="in"/><arg type="b" direction="out"/></method>
</interface></node>`;
export const MAX_PACKET = 1024 * 1024;
const text = value => typeof value === 'string' ? value.replace(/[\x00-\x1f\x7f\u202a-\u202e\u2066-\u2069]/g, ' ').replace(/\s+/g, ' ').trim() : '';

export function normalizeTrack(track) {
    if (!track || typeof track !== 'object')
        return null;
    const title = text(track.title ?? track.name);
    const artist = text(track.artist ?? track.artists?.map(item => item.name).join(', '));
    const album = text(typeof track.album === 'string' ? track.album : track.album?.name);
    const duration = Number(track.duration);
    if (!title || title.length > 512 || artist.length > 512 || album.length > 512 ||
        !Number.isFinite(duration) || duration < 0 || duration > 86400000)
        return null;
    return {title, artist, album, duration};
}

export function sameTrack(a, b) {
    const x = normalizeTrack(a);
    const y = normalizeTrack(b);
    return !!x && !!y && x.title === y.title && x.artist === y.artist && x.album === y.album &&
        Math.abs(x.duration - y.duration) <= 1000;
}

export function sessionTrack(session, id) {
    if (!session || !Array.isArray(session.queue) || !Array.isArray(session.order) ||
        !Number.isInteger(session.at) || session.at < 0)
        return null;
    const index = session.order[session.at];
    const current = Number.isInteger(index) ? session.queue[index] : null;
    if (!current || current.source !== 'netease' || String(current.id) !== String(id))
        return null;
    return normalizeTrack(current);
}

export function validatePacket(value, now = Date.now()) {
    if (!value || value.version !== 1 || value.source !== 'netease' ||
        typeof value.id !== 'string' || !/^(?:\d+|program:\d+(?::\d+)?)$/.test(value.id) ||
        !Number.isFinite(value.createdAt) || Math.abs(now - value.createdAt) > 60000 ||
        typeof value.player !== 'string' || !/^org\.mpris\.MediaPlayer2\.MyGo_Music(?:\.[A-Za-z0-9_]+)*$/.test(value.player) ||
        typeof value.playerTrackId !== 'string' || !/^\/(?:[A-Za-z0-9_]+\/?)*$/.test(value.playerTrackId))
        return null;
    const track = normalizeTrack(value.track);
    const lyrics = value.lyrics;
    if (!track || !lyrics || typeof lyrics !== 'object' || Array.isArray(lyrics))
        return null;
    for (const key of ['lrc', 'translation']) {
        if (lyrics[key] !== undefined && typeof lyrics[key] !== 'string')
            return null;
    }
    if (lyrics.lines !== undefined && (!Array.isArray(lyrics.lines) || lyrics.lines.length > 10000))
        return null;
    if (lyrics.lines?.some(line => !line || !Number.isFinite(line.start) || line.start < 0 ||
        line.start > 86400000 || typeof line.text !== 'string' || line.text.length > 16384 ||
        (line.translation !== undefined && typeof line.translation !== 'string')))
        return null;
    return {version: 1, source: 'netease', id: value.id, createdAt: value.createdAt,
        player: value.player, playerTrackId: value.playerTrackId, track, lyrics};
}

export function matchesPlayer(packet, state) {
    return !!state && packet.player === state.name && packet.playerTrackId === state.id &&
        sameTrack(packet.track, state);
}
