// Platform-independent lyric and playback logic, shared by GJS and Node tests.
const segmenter = new Intl.Segmenter(undefined, {granularity: 'grapheme'});

export function cleanText(value) {
    return String(value ?? '').replace(/[\x00-\x1f\x7f\u202a-\u202e\u2066-\u2069]/g, ' ')
        .replace(/\s+/g, ' ').trim();
}

export function graphemes(text) {
    return Array.from(segmenter.segment(text), part => part.segment);
}

export function displayText(text, limit, overflow = 'ellipsis', elapsedMs = 0, stepMs = 350) {
    const chars = graphemes(cleanText(text));
    limit = Math.max(4, Math.min(120, Math.trunc(limit) || 28));
    if (chars.length <= limit)
        return chars.join('');
    if (overflow !== 'scroll')
        return chars.slice(0, limit - 1).join('') + '…';
    const ring = [...chars, ' ', ' ', ' '];
    const at = Math.floor(Math.max(0, elapsedMs - 1000) / Math.max(80, stepMs)) % ring.length;
    return Array.from({length: limit}, (_, i) => ring[(at + i) % ring.length]).join('');
}

export function parseLrc(input) {
    if (typeof input !== 'string' || input.length > 1024 * 1024)
        throw new Error('歌词文件过大或格式无效');
    const offset = Number(input.match(/\[offset:\s*([+-]?\d+)\s*\]/i)?.[1] ?? 0);
    const rows = [];
    for (const raw of input.replace(/^\ufeff/, '').split(/\r?\n/)) {
        const tags = [...raw.matchAll(/\[(\d{1,3}):([0-5]\d)(?:[.:](\d{1,3}))?\]/g)];
        if (!tags.length)
            continue;
        const text = cleanText(raw.replace(/\[[^\]]*\]/g, '').replace(/<\d+:\d+(?:\.\d+)?>/g, ''));
        for (const tag of tags) {
            const ms = (Number(tag[1]) * 60 + Number(tag[2])) * 1000 +
                Number((tag[3] ?? '').padEnd(3, '0')) - offset;
            rows.push({time: Math.max(0, ms), text});
        }
        if (rows.length > 20000)
            throw new Error('歌词行数过多');
    }
    rows.sort((a, b) => a.time - b.time);
    const result = [];
    for (const row of rows) {
        const last = result.at(-1);
        if (last?.time === row.time) {
            if (row.text && !last.text.split(' / ').includes(row.text))
                last.text = last.text ? `${last.text} / ${row.text}` : row.text;
        } else {
            result.push(row);
        }
    }
    return result;
}

export function lineAt(lines, positionMs) {
    let low = 0;
    let high = lines.length;
    while (low < high) {
        const middle = (low + high) >>> 1;
        if (lines[middle].time <= positionMs)
            low = middle + 1;
        else
            high = middle;
    }
    return low - 1;
}

export function sourceLyrics(lyrics, translation = false) {
    if (Array.isArray(lyrics.lines) && lyrics.lines.length) {
        return lyrics.lines.map(line => ({time: line.start, text: cleanText(line.text) +
            (translation && cleanText(line.translation) ? ` / ${cleanText(line.translation)}` : '')}))
            .sort((a, b) => a.time - b.time);
    }
    const original = parseLrc(lyrics.lrc ?? '');
    if (!translation || !lyrics.translation)
        return original;
    const translated = parseLrc(lyrics.translation);
    let at = 0;
    return original.map(line => {
        while (at + 1 < translated.length &&
            Math.abs(translated[at + 1].time - line.time) < Math.abs(translated[at].time - line.time))
            at++;
        const candidate = translated[at];
        const extra = candidate && Math.abs(candidate.time - line.time) <= 500 ? candidate.text : '';
        return {time: line.time, text: line.text + (line.text && extra ? ` / ${extra}` : '')};
    });
}

export function positionAt(state, nowMs) {
    const elapsed = state.playback === 'Playing' ? Math.max(0, nowMs - state.observedAt) * state.rate : 0;
    const position = Math.max(0, state.position + elapsed);
    return state.duration > 0 ? Math.min(position, state.duration) : position;
}

export function trackKey(track) {
    return JSON.stringify([track.title, track.artist, track.album, Math.round(track.duration / 1000)]);
}

export function localNames(track) {
    const safe = value => cleanText(value).replace(/[\/\\]/g, '_').slice(0, 180);
    const title = safe(track.title);
    if (!title || title === '.' || title === '..')
        return [];
    return [...new Set([`${safe(track.artist)} - ${title}.lrc`, `${title}.lrc`])];
}

export function lookupUrl(track) {
    const fields = {track_name: track.title, artist_name: track.artist};
    if (track.album)
        fields.album_name = track.album;
    const duration = Math.round(track.duration / 1000);
    if (duration >= 1 && duration <= 3600)
        fields.duration = String(duration);
    return 'https://lrclib.net/api/get?' + Object.entries(fields)
        .map(([key, value]) => `${key}=${encodeURIComponent(value)}`).join('&');
}
