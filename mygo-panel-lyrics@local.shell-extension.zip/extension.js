import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Pango from 'gi://Pango';
import St from 'gi://St';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {cleanText, displayText, lineAt, sourceLyrics, trackKey} from './core.js';
import {LyricSource} from './lyrics.js';
import {MprisWatcher} from './mpris.js';
import {ForwardReceiver} from './forward-receiver.js';

export default class MygoPanelLyrics extends Extension {
    enable() {
        this._alive = true;
        this._settings = this.getSettings();
        this._lines = [];
        this._generation = 0;
        this._key = null;
        this._displayToken = null;
        this._status = '等待 MyGo Music 播放';
        this._source = new LyricSource();
        this._createIndicator();
        this._receiver = new ForwardReceiver(() => {
            if (this._settings.get_string('lyric-source') === 'plugin' && this._receiver.lookup(this._state))
                this._loadLyrics();
        });
        this._settingsId = this._settings.connect('changed', (_settings, key) => {
            if (key === 'position' || key === 'panel-index') {
                this._indicator.destroy();
                this._createIndicator();
            }
            this._displayToken = null;
            this._applyStyle();
            if (['online-enabled', 'local-directory', 'lyric-source', 'show-translation'].includes(key))
                this._loadLyrics();
            this._tick();
        });
        this._monitorId = Main.layoutManager.connect('monitors-changed', () => this._applyStyle());
        this._watcher = new MprisWatcher(state => this._stateChanged(state));
        this._watcher.start();
        this._timer = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 100, () => {
            this._tick();
            return GLib.SOURCE_CONTINUE;
        });
    }

    _createIndicator() {
        this._indicator = new PanelMenu.Button(0.5, 'MyGo 顶栏歌词', false);
        this._indicator.add_style_class_name('mygo-panel-lyrics');
        this._label = new St.Label({text: '', y_align: Clutter.ActorAlign.CENTER,
            style_class: 'mygo-panel-lyrics-label'});
        this._label.clutter_text.set_single_line_mode(true);
        this._label.clutter_text.set_ellipsize(Pango.EllipsizeMode.END);
        this._indicator.add_child(this._label);
        this._statusItem = new PopupMenu.PopupMenuItem(this._status, {reactive: false});
        this._indicator.menu.addMenuItem(this._statusItem);
        this._indicator.menu.addAction('重新读取歌词', () => {
            if (this._state) {
                this._source.forget(this._state);
                this._loadLyrics();
            }
        });
        this._indicator.menu.addAction('歌词显示设置…', () => this.openPreferences());
        const position = this._settings.get_string('position');
        const box = Main.panel[`_${position}Box`];
        const index = Math.min(this._settings.get_int('panel-index'), box.get_n_children());
        Main.panel.addToStatusArea(this.uuid, this._indicator, index, position);
        this._indicator.hide();
        this._applyStyle();
    }

    _applyStyle() {
        const monitor = Main.layoutManager.primaryMonitor;
        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        const available = monitor ? Math.floor(monitor.width / scale * 0.4) : 600;
        const width = Math.max(80, Math.min(this._settings.get_int('max-width'), available));
        this._label.set_style(`font-size: ${this._settings.get_int('font-size')}px; width: ${width}px;`);
        const align = this._settings.get_string('alignment');
        this._label.clutter_text.set_line_alignment({left: Pango.Alignment.LEFT,
            center: Pango.Alignment.CENTER, right: Pango.Alignment.RIGHT}[align]);
    }

    _stateChanged(state) {
        this._state = state;
        const key = state ? `${state.name}:${state.id}:${trackKey(state)}` : null;
        if (key !== this._key) {
            this._key = key;
            this._loadLyrics();
        }
        this._tick();
    }

    async _loadLyrics() {
        this._loadCancel?.cancel();
        this._loadCancel = new Gio.Cancellable();
        const cancel = this._loadCancel;
        const generation = ++this._generation;
        this._lines = [];
        this._displayToken = null;
        if (!this._state) {
            this._setStatus('等待 MyGo Music 播放');
            return;
        }
        if (this._settings.get_string('lyric-source') === 'plugin') {
            const lyrics = this._receiver.lookup(this._state);
            try {
                this._lines = lyrics ? sourceLyrics(lyrics, this._settings.get_boolean('show-translation')) : [];
                this._setStatus(lyrics ? (this._lines.length ? '网易云原始歌词（来自当前音乐源）' : '当前音乐源没有返回同步歌词') :
                    '等待网易云原始歌词；允许插件启动 gjs 后重新播放歌曲');
            } catch (_) {
                this._lines = [];
                this._setStatus('来源歌词格式无效，无法显示时间轴');
            }
            this._tick();
            return;
        }
        this._setStatus('正在匹配歌词…');
        try {
            const result = await this._source.load(this._state, {
                directory: this._settings.get_string('local-directory').trim(),
                online: this._settings.get_boolean('online-enabled'),
            }, cancel);
            if (!this._alive || generation !== this._generation)
                return;
            this._lines = result.lines;
            this._setStatus(result.status);
        } catch (_) {
            if (!this._alive || generation !== this._generation || cancel.is_cancelled())
                return;
            this._setStatus('歌词获取失败，请检查网络或本地文件后重新匹配');
        }
        this._tick();
    }

    _setStatus(text) {
        this._status = text;
        this._statusItem.label.set_text(text);
    }

    _tick() {
        if (!this._alive)
            return;
        if (!this._state || this._state.playback === 'Stopped' ||
            (this._settings.get_boolean('hide-paused') && this._state.playback !== 'Playing')) {
            this._label.remove_all_transitions();
            this._indicator.hide();
            this._displayToken = null;
            return;
        }
        const position = this._watcher.position() + this._settings.get_int('offset-ms');
        const index = lineAt(this._lines, position);
        const row = this._lines[index];
        const text = row?.text || (this._settings.get_boolean('show-track') ?
            `${this._state.title}${this._state.artist ? ` · ${this._state.artist}` : ''}` : '');
        if (!text) {
            this._indicator.hide();
            this._displayToken = null;
            return;
        }
        this._indicator.show();
        this._indicator.accessible_name = cleanText(text);
        const rendered = displayText(text, this._settings.get_int('max-chars'),
            this._settings.get_string('overflow'), row ? position - row.time : 0,
            this._settings.get_int('scroll-ms'));
        const token = `${this._key}:${index}:${text}`;
        if (token !== this._displayToken) {
            const animate = this._displayToken !== null;
            this._displayToken = token;
            this._animateText(rendered, animate);
        } else if (!this._animating && rendered !== this._label.text) {
            // Long-line scrolling must not restart the line transition animation.
            this._label.set_text(rendered);
        }
    }

    _animateText(text, animate) {
        const label = this._label;
        label.remove_all_transitions();
        label.opacity = 255;
        label.translation_y = 0;
        this._animating = false;
        const mode = this._settings.get_string('transition');
        const duration = this._settings.get_int('transition-ms');
        if (!animate || mode === 'none' || !duration || !St.Settings.get().enable_animations) {
            label.set_text(text);
            return;
        }
        this._animating = true;
        label.ease({opacity: 0, translation_y: mode === 'slide' ? -8 : 0,
            duration: duration / 2, mode: Clutter.AnimationMode.EASE_IN_QUAD,
            onComplete: () => {
                if (!this._alive || label !== this._label)
                    return;
                label.set_text(text);
                label.translation_y = mode === 'slide' ? 8 : 0;
                label.ease({opacity: 255, translation_y: 0, duration: duration / 2,
                    mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                    onComplete: () => { this._animating = false; }});
            }});
    }

    disable() {
        this._alive = false;
        this._generation++;
        this._loadCancel?.cancel();
        this._watcher?.destroy();
        this._receiver?.destroy();
        this._source?.destroy();
        if (this._timer)
            GLib.Source.remove(this._timer);
        if (this._monitorId)
            Main.layoutManager.disconnect(this._monitorId);
        if (this._settingsId)
            this._settings.disconnect(this._settingsId);
        this._label?.remove_all_transitions();
        this._indicator?.destroy();
        this._watcher = this._source = this._settings = this._indicator = this._label = null;
        this._receiver = null;
        this._loadCancel = this._state = null;
        this._lines = [];
        this._timer = this._monitorId = this._settingsId = 0;
    }
}
