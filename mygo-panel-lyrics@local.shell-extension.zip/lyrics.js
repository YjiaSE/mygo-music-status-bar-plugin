import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Soup from 'gi://Soup?version=3.0';
import {localNames, lookupUrl, parseLrc, trackKey} from './core.js';

const LIMIT = 1024 * 1024;
const decode = bytes => new TextDecoder('utf-8', {fatal: true}).decode(bytes);

function pause(ms, cancel) {
    return new Promise((resolve, reject) => {
        if (cancel.is_cancelled()) {
            reject(new Error('CANCELLED'));
            return;
        }
        const signal = cancel.connect(() => {
            GLib.Source.remove(timer);
            // A Cancellable handler must not disconnect itself while it is running.
            GLib.idle_add_once(GLib.PRIORITY_DEFAULT, () => cancel.disconnect(signal));
            reject(new Error('CANCELLED'));
        });
        const timer = GLib.timeout_add_once(GLib.PRIORITY_DEFAULT, Math.max(1, ms), () => {
            cancel.disconnect(signal);
            resolve();
        });
    });
}

async function readBounded(stream, cancel) {
    const parts = [];
    let size = 0;
    try {
        while (true) {
            const bytes = await new Promise((resolve, reject) => stream.read_bytes_async(16384,
                GLib.PRIORITY_DEFAULT, cancel, (source, result) => {
                    try { resolve(source.read_bytes_finish(result).toArray()); } catch (error) { reject(error); }
                }));
            if (!bytes.length)
                break;
            size += bytes.length;
            if (size > LIMIT)
                throw new Error('TOO_LARGE');
            parts.push(bytes);
        }
    } finally {
        // The stream is already fully read, failed or cancelled. Close asynchronously.
        stream.close_async(GLib.PRIORITY_DEFAULT, null, (source, result) => {
            try { source.close_finish(result); } catch (_) { /* No contents logged. */ }
        });
    }
    const combined = new Uint8Array(size);
    let at = 0;
    for (const part of parts) {
        combined.set(part, at);
        at += part.length;
    }
    return decode(combined);
}

export class LyricSource {
    constructor({endpoint = null} = {}) {
        // endpoint injection is for the isolated HTTP fixture; never exposed as a setting.
        this._endpoint = endpoint;
        this._session = new Soup.Session({timeout: 10,
            user_agent: 'MyGoPanelLyrics/0.1.0 (local GNOME desktop extension)'});
        this._cache = new Map();
        this._notBefore = 0;
        this._chain = Promise.resolve();
        this._alive = true;
    }

    async load(track, {directory, online}, cancel) {
        if (directory) {
            const base = directory === '~' ? GLib.get_home_dir() : directory.startsWith('~/') ?
                GLib.build_filenamev([GLib.get_home_dir(), directory.slice(2)]) : directory;
            for (const name of localNames(track)) {
                const file = Gio.File.new_for_path(GLib.build_filenamev([base, name]));
                try {
                    const stream = await new Promise((resolve, reject) => file.read_async(
                        GLib.PRIORITY_DEFAULT, cancel, (source, result) => {
                            try { resolve(source.read_finish(result)); } catch (error) { reject(error); }
                        }));
                    const lines = parseLrc(await readBounded(stream, cancel));
                    if (lines.length)
                        return {lines, status: '本地 LRC'};
                } catch (error) {
                    if (cancel.is_cancelled())
                        throw error;
                    if (!error.matches?.(Gio.io_error_quark(), Gio.IOErrorEnum.NOT_FOUND))
                        return {lines: [], status: '本地歌词无法读取（需 UTF-8、1 MiB 以内）'};
                }
            }
        }
        if (!online)
            return {lines: [], status: '未找到本地歌词；在线匹配已关闭'};
        if (!track.title || !track.artist)
            return {lines: [], status: '缺少歌名或歌手，无法在线匹配'};
        const key = trackKey(track);
        const cached = this._cache.get(key);
        if (cached && Date.now() - cached.at < 30 * 60 * 1000)
            return cached.value;
        const pending = this._chain.catch(() => {}).then(async () => {
            if (!this._alive || cancel.is_cancelled())
                throw new Error('CANCELLED');
            const remaining = this._notBefore - Date.now();
            if (remaining > 1000)
                return {lines: [], status: '查询冷却中，请稍后点击重新匹配'};
            if (remaining > 0)
                await pause(remaining, cancel);
            if (!this._alive || cancel.is_cancelled())
                throw new Error('CANCELLED');
            return this._online(track, key, cancel);
        });
        this._chain = pending;
        return pending;
    }

    async _online(track, key, cancel) {
        const url = this._endpoint ? lookupUrl(track).replace('https://lrclib.net/api/get', this._endpoint) : lookupUrl(track);
        const message = Soup.Message.new('GET', url);
        message.set_flags(Soup.MessageFlags.NO_REDIRECT);
        this._notBefore = Date.now() + 500;
        const stream = await new Promise((resolve, reject) => this._session.send_async(message,
            GLib.PRIORITY_DEFAULT, cancel, (session, result) => {
                try { resolve(session.send_finish(result)); } catch (error) { reject(error); }
            }));
        // get_status() is enum-typed in GI and rejects valid HTTP codes such as 429.
        const status = message.status_code;
        if (status !== 200) {
            stream.close_async(GLib.PRIORITY_DEFAULT, null, (source, result) => {
                try { source.close_finish(result); } catch (_) { /* Ignore close failures. */ }
            });
            if (status === 429 || status === 503) {
                const header = message.get_response_headers().get_one('Retry-After');
                const seconds = /^\d+$/.test(header ?? '') ? Number(header) :
                    Math.ceil((Date.parse(header) - Date.now()) / 1000);
                const wait = Number.isFinite(seconds) ? Math.max(1, seconds) : 60;
                this._notBefore = Date.now() + wait * 1000 * (1 + Math.random() * 0.3);
                return {lines: [], status: '歌词服务繁忙，冷却后可重新匹配'};
            }
            if (status === 404)
                return this._remember(key, {lines: [], status: '未匹配到歌词，可添加本地 LRC'});
            return {lines: [], status: `歌词服务暂不可用（HTTP ${status}）`};
        }
        const type = message.get_response_headers().get_content_type()[0];
        if (type !== 'application/json') {
            stream.close_async(GLib.PRIORITY_DEFAULT, null, (source, result) => {
                try { source.close_finish(result); } catch (_) { /* Ignore close failures. */ }
            });
            return {lines: [], status: '歌词服务返回了非 JSON 内容'};
        }
        const payload = JSON.parse(await readBounded(stream, cancel));
        if (payload.instrumental)
            return this._remember(key, {lines: [], status: '纯音乐'});
        const lines = parseLrc(payload.syncedLyrics ?? '');
        return this._remember(key, {lines, status: lines.length ? 'LRCLIB 同步歌词' : '没有时间轴歌词，可添加本地 LRC'});
    }

    _remember(key, value) {
        this._cache.delete(key);
        this._cache.set(key, {at: Date.now(), value});
        if (this._cache.size > 100)
            this._cache.delete(this._cache.keys().next().value);
        return value;
    }

    forget(track) { this._cache.delete(trackKey(track)); }
    destroy() {
        this._alive = false;
        this._session.abort();
        this._cache.clear();
    }
}
