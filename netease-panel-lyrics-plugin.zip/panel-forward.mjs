// SPDX-License-Identifier: AGPL-3.0-only
import Gio from 'gi://Gio';
import GioUnix from 'gi://GioUnix';
import GLib from 'gi://GLib';
import System from 'system';
import {BUS_NAME, BUS_PATH, BUS_IFACE, MAX_PACKET, normalizeTrack, sameTrack, sessionTrack} from './forward-contract.js';

const PLAYER_PATH = '/org/mpris/MediaPlayer2';
const PLAYER_IFACE = 'org.mpris.MediaPlayer2.Player';
const unpack = value => value instanceof GLib.Variant ? unpack(value.deepUnpack()) :
    Array.isArray(value) ? value.map(unpack) : value && typeof value === 'object' ?
        Object.fromEntries(Object.entries(value).map(([key, item]) => [key, unpack(item)])) : value;

function input() {
    const stream = new GioUnix.InputStream({fd: 0, close_fd: false});
    const chunks = [];
    let size = 0;
    while (true) {
        const chunk = stream.read_bytes(16384, null).toArray();
        if (!chunk.length) break;
        size += chunk.length;
        if (size > MAX_PACKET) throw new Error('TOO_LARGE');
        chunks.push(chunk);
    }
    const data = new Uint8Array(size);
    let at = 0;
    for (const chunk of chunks) { data.set(chunk, at); at += chunk.length; }
    const packet = JSON.parse(new TextDecoder('utf-8', {fatal: true}).decode(data));
    if (packet.version !== 1 || packet.source !== 'netease' || typeof packet.id !== 'string' ||
        !Number.isFinite(packet.createdAt) || Math.abs(Date.now() - packet.createdAt) > 60000)
        throw new Error('INVALID');
    return packet;
}

function restoreTrack(id) {
    // For a restored queue no toTrack() call may have occurred in this plugin.
    // Read only its currently selected song's metadata; never access settings,
    // account storage or a whole queue's contents outside this helper.
    try {
        const dir = Gio.File.new_for_uri(import.meta.url).get_parent();
        const session = dir.get_parent().get_parent().get_child('session.json');
        const stream = session.read(null);
        const bytes = stream.read_bytes(2 * MAX_PACKET + 1, null).toArray();
        stream.close(null);
        if (bytes.length > 2 * MAX_PACKET) return null;
        return sessionTrack(JSON.parse(new TextDecoder().decode(bytes)), id);
    } catch (_) { return null; }
}

function call(bus, name, path, iface, method, args, cancel) {
    return new Promise((resolve, reject) => bus.call(name, path, iface, method, args, null,
        Gio.DBusCallFlags.NONE, 1200, cancel, (connection, result) => {
            try { resolve(connection.call_finish(result)); } catch (error) { reject(error); }
        }));
}

async function forward(packet, cancel) {
    const bus = await new Promise((resolve, reject) => Gio.bus_get(Gio.BusType.SESSION, cancel,
        (_source, result) => { try { resolve(Gio.bus_get_finish(result)); } catch (error) { reject(error); } }));
    for (let attempt = 0; attempt < 8; attempt++) {
        const track = normalizeTrack(packet.track) ?? restoreTrack(packet.id);
        if (track) {
            const names = unpack(await call(bus, 'org.freedesktop.DBus', '/org/freedesktop/DBus',
                'org.freedesktop.DBus', 'ListNames', null, cancel))[0];
            for (const name of names.filter(item => /^org\.mpris\.MediaPlayer2\.MyGo_Music(?:\.|$)/.test(item))) {
                const props = unpack(await call(bus, name, PLAYER_PATH, 'org.freedesktop.DBus.Properties',
                    'GetAll', new GLib.Variant('(s)', [PLAYER_IFACE]), cancel))[0];
                const meta = props.Metadata ?? {};
                const current = normalizeTrack({title: meta['xesam:title'],
                    artist: (meta['xesam:artist'] ?? []).join(', '), album: meta['xesam:album'],
                    duration: Number(meta['mpris:length'] ?? 0) / 1000});
                if (!sameTrack(track, current) || props.PlaybackStatus === 'Stopped') continue;
                const message = JSON.stringify({...packet, track, player: name,
                    playerTrackId: String(meta['mpris:trackid'] ?? '')});
                if (new TextEncoder().encode(message).length > MAX_PACKET) return false;
                const reply = await call(bus, BUS_NAME, BUS_PATH, BUS_IFACE, 'Publish',
                    new GLib.Variant('(s)', [message]), cancel);
                return reply.deepUnpack()[0];
            }
        }
        await new Promise(resolve => GLib.timeout_add_once(GLib.PRIORITY_DEFAULT, 150, resolve));
    }
    return false;
}

const loop = new GLib.MainLoop(null, false);
const cancel = new Gio.Cancellable();
const timer = GLib.timeout_add_once(GLib.PRIORITY_DEFAULT, 4500, () => cancel.cancel());
let okay = false;
try {
    const packet = input();
    forward(packet, cancel).then(result => { okay = !!result; }).catch(() => {}).finally(() => loop.quit());
    loop.run();
} catch (_) { /* Never log a payload, query, file path or account data. */ }
if (!cancel.is_cancelled()) GLib.Source.remove(timer);
print(JSON.stringify({ok: okay}));
System.exit(okay ? 0 : 1);
