async function bridge(command, key, value) {
    if (host.platform !== 'linux')
        throw Object.assign(new Error('此插件需要 Ubuntu GNOME 桌面'), {code: 'unsupported'});
    const process = host.spawn('gjs', ['-m', `${host.dir}/bridge.mjs`, command, key ?? '', value ?? '']);
    const line = await process.readLine();
    await process.wait();
    if (!line)
        throw new Error('无法连接顶栏设置：请先安装 GNOME 扩展并允许此插件启动 gjs');
    const reply = JSON.parse(line);
    if (!reply.ok)
        throw new Error(reply.error);
    return reply;
}

export async function setSetting({key, value}) {
    // Only an explicit setting edit writes that one key. Merely opening the page never writes.
    await bridge('set', key, value);
}

export async function browse() {
    try {
        const reply = await bridge('status');
        return {title: '顶栏歌词', subtitle: 'Ubuntu GNOME · MyGo Music',
            description: `当前系统设置：${reply.summary}\n在本插件设置中修改位置、长度及交替样式；更多选项可在 GNOME 扩展设置中调整。\n默认复用网易云插件已返回的原始歌词，需要安装网易云转发补丁并允许其启动 gjs。GNOME 扩展通过 MPRIS 同步播放进度。`,
            sections: [{title: '使用说明', empty: '播放歌曲后歌词会自动显示。点击顶栏歌词可查看来源、重新匹配和打开显示设置。'}]};
    } catch (error) {
        return {title: '顶栏歌词', description: String(error.message),
            sections: [{title: '安装提示', empty: '先安装配套 mygo-panel-lyrics@local GNOME 扩展，在 MyGo 设置中允许本插件启动 gjs。Wayland 首次安装扩展后需要注销并重新登录。'}]};
    }
}
