import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import System from 'system';

const allowed = {
    'lyric-source': ['s', ['plugin', 'fallback']],
    'show-translation': ['b'],
    position: ['s', ['left', 'center', 'right']],
    'panel-index': ['i', 0, 20],
    'max-chars': ['i', 4, 120],
    'max-width': ['i', 80, 1200],
    transition: ['s', ['none', 'fade', 'slide']],
    'transition-ms': ['i', 0, 1000],
    overflow: ['s', ['ellipsis', 'scroll']],
    'local-directory': ['path'],
    'online-enabled': ['b'],
};

try {
    const schemaDir = GLib.build_filenamev([GLib.get_user_data_dir(), 'gnome-shell', 'extensions',
        'mygo-panel-lyrics@local', 'schemas']);
    const source = Gio.SettingsSchemaSource.new_from_directory(schemaDir,
        Gio.SettingsSchemaSource.get_default(), false);
    const schema = source.lookup('org.gnome.shell.extensions.mygo-panel-lyrics', false);
    if (!schema)
        throw new Error('请先安装配套 GNOME 顶栏歌词扩展');
    const settings = new Gio.Settings({settings_schema: schema});
    const [command, key, raw = ''] = ARGV;
    if (command === 'set') {
        const spec = allowed[key];
        if (!spec)
            throw new Error('不支持的设置项');
        const value = raw.trim();
        if (spec[0] === 'i') {
            if (!/^\d+$/.test(value) || Number(value) < spec[1] || Number(value) > spec[2])
                throw new Error(`请输入 ${spec[1]}–${spec[2]} 的整数`);
            settings.set_int(key, Number(value));
        } else if (spec[0] === 's') {
            if (!spec[1].includes(value))
                throw new Error('无效的选项');
            settings.set_string(key, value);
        } else if (spec[0] === 'b') {
            if (!['true', 'false'].includes(value))
                throw new Error('请输入 true 或 false');
            settings.set_boolean(key, value === 'true');
        } else {
            if (value && !value.startsWith('/') && !value.startsWith('~/'))
                throw new Error('歌词目录须为绝对路径或 ~/ 开头');
            settings.set_string(key, value);
        }
        Gio.Settings.sync();
        print(JSON.stringify({ok: true}));
    } else if (command === 'status') {
        const positions = {left: '左侧', center: '中间', right: '右侧'};
        const transitions = {none: '直接切换', fade: '淡入淡出', slide: '上下滑动'};
        const source = settings.get_string('lyric-source') === 'plugin' ? '网易云原始歌词' : '独立匹配';
        const summary = `${source} · ${positions[settings.get_string('position')]} · ${settings.get_int('max-chars')} 字符 · ${settings.get_int('max-width')} 像素 · ${transitions[settings.get_string('transition')]}`;
        print(JSON.stringify({ok: true, summary}));
    } else {
        throw new Error('不支持的命令');
    }
} catch (_) {
    // Never print arbitrary paths, DBus errors, or user data.
    print(JSON.stringify({ok: false, error: '设置未应用：请确认已安装 GNOME 扩展，且输入值符合字段范围。'}));
    System.exit(1);
}
